# Data Analysis ----

# Use renv to restore the packages
renv::restore()

# Libraries ####
library(here)
library(tidyverse)
library(brms)
library(rstanarm)
library(gridExtra)
library(rstan)
library(bayesplot)
library(RColorBrewer)
library(patchwork)

# Tidy ####
# Load dataframe
dmi <- read.csv2(here("data", "dmi_data.csv"), sep= ",", dec= ".")

dmi <- dmi %>% 
  mutate(season = as.factor(season),
         Region = as.factor(Region),
         Metric = as.factor(Metric),
         sex = as.factor(sex),
         ID = as.factor(ID),
         uniqueID = as.factor(uniqueID)) %>% 
  na.omit()

ggplot(dmi, aes(x = Value, fill = Metric)) +
  geom_histogram(position = "identity", alpha = 0.5, bins = 30) +
  facet_wrap(~season)

#check if there's any 0 or 1
any(dmi$Value >=1, na.rm = TRUE)
any(dmi$Value <=0, na.rm = TRUE)

set.seed(1234)

# Brain volume decrease ####
dmi %>%
  ggplot(aes(x = season, y = Volume, fill = season)) +
  geom_boxplot(alpha = 0.6) +
  facet_wrap(~ Region, scales = "free_y") +
  labs(title = "Regional volume by season", x = "Season", y = "Volume (mm³)")
brain_model <-  brm(bf(brainvolume ~ season + (1|ID)), data=dmi,
                    prior = c(prior(exponential(0.8), class = "sd", group = "ID")),
                    cores= 4, iter = 4000, seed ="1234",
                    backend = "cmdstanr",
                    control=list(adapt_delta=0.999, max_treedepth = 12))

plot(conditional_effects(brain_model, "season"), points = TRUE)
pp_check(brain_model, type = "error_hist")

# Calculate percentages
post_samples <- as.data.frame(brain_model)
percent_decrease <- with(post_samples, (-b_season2 / b_Intercept) * 100)
mean_percent_decrease <- mean(percent_decrease)
ci_percent_decrease <- quantile(percent_decrease, probs = c(0.025, 0.975))

cat("Mean percentage decrease:", round(mean_percent_decrease, 2), "%\n")
cat("95% Credible Interval: [", round(ci_percent_decrease[1], 2), ",", round(ci_percent_decrease[2], 2), "]%\n")

## Brain regions volume decrease ####

region_data_list <- dmi %>%
  group_by(Region) %>%
  group_split(.keep = TRUE)

region_names <- dmi %>%
  group_by(Region) %>%
  group_keys() %>%
  pull(Region)

# Define function for brain region model
fit_region_model <- function(data) {
  brm(bf(Volume ~ season + (1|ID)), data = data,
      prior = c(prior(exponential(0.8), class = "sd", group = "ID"),
                prior(normal(-2, 4), class = "b", coef = "season2")),
      cores = 4, iter = 4000, seed = 1234,
      backend = "cmdstanr",
      control = list(adapt_delta = 0.999, max_treedepth = 12),
      silent = 2, refresh = 0)
}

region_models <- map(region_data_list, fit_region_model)

names(region_models) <- region_names

season_effects <- map_dfr(region_models, ~ {
  posterior_summary(.x, pars = "b_season2") %>%
    as_tibble(rownames = "parameter")
}, .id = "Region")


# Intracellular water volume fraction ####
data_intra <- filter(dmi, Metric == "intra") %>%
  droplevels() %>% 
  na.omit()

ggplot(data_intra, aes(x = as.factor(season), y = Value)) +
  geom_boxplot(alpha = 0.5) +
  geom_jitter(color = "black", alpha = 0.5, width = 0.2) +
  labs(x = "Season", y = "Value")

#I need all parameters as numbers (not factors)
data_intra$ID <- as.integer(data_intra$ID)
data_intra$season <- as.numeric(data_intra$season) - 1
data_intra$Region_in <- as.integer(data_intra$Region)
for (region_level in levels(data_intra$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_intra[[interaction_name]] <- ifelse(data_intra$Region == region_level, data_intra$season, 0)
}

## start of model
stan_data_intra <- list(
  N = nrow(data_intra),
  N_ID = length(unique(data_intra$ID)),
  N_regions = length(unique(data_intra$Region_in)), 
  value = data_intra$Value,
  season = data_intra$season,
  status = data_intra$status,
  interactions = as.matrix(data_intra[, grepl("interaction_", names(data_intra))]),
  ID = data_intra$ID,
  region = data_intra$Region_in)

fit_intra <- stan(file = 'model_stan.stan', 
                        data = stan_data_intra, warmup = 2000, iter = 4000, 
                  chains = 4, cores = 4,
                  control = list(stepsize = 0.01, adapt_delta = 0.9),
                  seed = 1234)
print(fit_intra, pars = c('alpha_intercept', 'beta_season', 'beta_interaction','phi', 'ID_effects'),
      digits_summary = 3,  probs = c(.025, .5, .975))

pp_check(stan_data_intra$value,
  extract(fit_intra, pars = "y_rep")$y_rep, #mean of replicated data (predictions)
  fun = "dens_overlay")

### plot ####
predicted_values <- extract(fit_intra)$y_rep
mean_predictions <- apply(predicted_values, 2, mean) #mean across samples for each observation (column)
data_intra$predicted_mean_value <- mean_predictions

residuals_mean_based <- data_intra$Value - mean_predictions
plot(mean_predictions, residuals_mean_based, main = "Residuals vs. Predicted Values",
     xlab = "Predicted Values", ylab = "Residuals")
abline(h = 0, col = "red")
ci_lower <- apply(predicted_values, 2, quantile, probs = 0.025)
ci_upper <- apply(predicted_values, 2, quantile, probs = 0.975)
data_intra$ci_lower <- ci_lower
data_intra$ci_upper <- ci_upper

intra <- ggplot(data_intra, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Intracellular Water Volume Proportion", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw() +
  theme(legend.position = "none",
        axis.title.x = element_text(size = 15, margin = margin(t = 15)),
        axis.title.y = element_text(size = 15, margin = margin(r = 15)))

custom_labels <- c(AON = "Anterior Olfactory Nucleus", olfactorybulb = "Olfactory Bulb",
                   neocortex = "Neocortex",  Naccumbens = "Nucleus Accumbens",
                   caudoputamen = "Caudoputamen",  amygdala = "Amygdala",
                   hippocampus = "Hippocampus",  OT = "Olfactory Tubercle",  midbrain = "Midbrain",
                   ponsmedulla = "Pons and Medulla",
                   piriformentorhinal = "Piriform and Entorhinal Cortices",
                   thalamus = "Thalamus",  cerebellum = "Cerebellum")

intra_region <- ggplot(data_intra, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Intracellular Water Volume Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
    facet_wrap(~Region, labeller = as_labeller(custom_labels)) +
  theme_bw() +
  theme(legend.position = "none")


# Extracellular water volume fraction ####
data_extra <- filter(dmi, Metric == "extra") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_extra$season <- as.numeric(data_extra$season) - 1 
data_extra$ID <- as.integer(data_extra$ID)
data_extra$Region_in <- as.integer(data_extra$Region)
for (region_level in levels(data_extra$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_extra[[interaction_name]] <- ifelse(data_extra$Region == region_level, data_extra$season, 0)
}

## start of model
stan_data_extra <- list(
  N = nrow(data_extra),
  N_ID = length(unique(data_extra$ID)),
  N_regions = length(unique(data_extra$Region_in)), 
  value = data_extra$Value,
  season = data_extra$season,
  interactions = as.matrix(data_extra[, grepl("interaction_", names(data_extra))]),
  ID = data_extra$ID,
  region = data_extra$Region_in)

fit_extra <- stan(file = 'model_stan.stan', 
            data = stan_data_extra, warmup = 2000, iter = 4000, 
            chains = 4, cores = 4,
            control = list(stepsize = 0.01),
            seed = 1234)
print(fit_extra,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3, probs = c(.025, .5, .975))

### plot ####
predicted_values_e <- extract(fit_extra)$y_rep
mean_predictions_e <- apply(predicted_values_e, 2, mean) # Mean across rows (samples) for each observation (column)
data_extra$predicted_mean_value <- mean_predictions_e

residuals_mean_based <- data_extra$Value - mean_predictions_e
plot(mean_predictions_e, residuals_mean_based, main = "Residuals vs. Predicted Values",
     xlab = "Predicted Values", ylab = "Residuals")
abline(h = 0, col = "red")

ci_lower <- apply(predicted_values_e, 2, quantile, probs = 0.025)
ci_upper <- apply(predicted_values_e, 2, quantile, probs = 0.975)
data_extra$ci_lower <- ci_lower
data_extra$ci_upper <- ci_upper

extra <- ggplot(data_extra, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Extracellular Water Volume Proportion", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw() +
  theme(legend.position = "none",
    axis.title.x = element_text(size = 15, margin = margin(t = 15)),  
    axis.title.y = element_text(size = 15, margin = margin(r = 15)))

extra_region <- ggplot(data_extra, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Extracellular Water Volume Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  #scale_fill_brewer(palette = "Pastel1", name = "Season", labels = c("Summer", "Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw() +
  theme(legend.position = 'none')


# fa ####
data_fa <- filter(dmi, Metric == "fa") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_fa$season <- as.numeric(data_fa$season) - 1 
data_fa$ID <- as.integer(data_fa$ID)
data_fa$Region_in <- as.integer(data_fa$Region)
for (region_level in levels(data_fa$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_fa[[interaction_name]] <- ifelse(data_fa$Region == region_level, data_fa$season, 0)
}

## start of model

stan_data_fa <- list(
  N = nrow(data_fa),
  N_ID = length(unique(data_fa$ID)),
  N_regions = length(unique(data_fa$Region_in)), 
  value = data_fa$Value,
  season = data_fa$season,
  interactions = as.matrix(data_fa[, grepl("interaction_", names(data_fa))]),
  ID = data_fa$ID,
  region = data_fa$Region_in)

fit_fa <- stan(file = 'model_stan.stan', 
                  data = stan_data_fa, warmup = 2000, iter = 4000, 
                  chains = 4, cores = 4,
                  control = list(stepsize = 0.01),
               seed = 1234)
print(fit_fa,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3,
      probs = c(.025, .5, .975))

pp_check(stan_data_fa$value,
         extract(fit_fa, pars = "y_rep")$y_rep, #mean of predictions
         fun = "dens_overlay")

obs_min <- min(data_fa$Value)
obs_max <- max(data_fa$Value)
y_rep_samples <- extract(fit_fa, pars = "y_rep")$y_rep
pp_min <- apply(y_rep_samples, 2, min)
pp_max <- apply(y_rep_samples, 2, max)
ppF <- data.frame(
  Stat = c(rep("Min", length(pp_min)), rep("Max", length(pp_max))),
  Value = c(pp_min, pp_max))

ggplot(ppF, aes(x = Stat, y = Value, color = Stat)) +
  geom_jitter(width = 0.1, alpha = 0.5) +
  geom_hline(yintercept = obs_min, linetype = "dashed", color = "blue") +
  geom_hline(yintercept = obs_max, linetype = "dashed", color = "red") +
  labs(title = "Posterior Predictive Check: Min and Max Values",
       y = "Value",
       x = "") +
  theme_bw()

### plot ####
predicted_values_f <- extract(fit_fa)$y_rep
mean_predictions_f <- apply(predicted_values_f, 2, mean) # Mean across rows (samples) for each observation (column)
data_fa$predicted_mean_value <- mean_predictions_f

fa <- ggplot(data_fa, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Fractional Anisotropy (FA)", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw() +
  theme(legend.position = "none",
        axis.title.x = element_text(size = 15, margin = margin(t = 15)),
        axis.title.y = element_text(size = 15, margin = margin(r = 15)))

fa_region <- ggplot(data_fa, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Fractional Anisotropy (FA) Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  #scale_fill_brewer(palette = "Pastel1", name = "Season", labels = c("Summer", "Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw()+
  theme(legend.position = 'none')

# ad ####
data_ad <- filter(dmi, Metric == "ad") %>%
  filter(Region!= "brainvolume") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_ad$season <- as.numeric(data_ad$season) - 1 
data_ad$ID <- as.integer(data_ad$ID)
data_ad$Region_in <- as.integer(data_ad$Region)
for (region_level in levels(data_ad$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_ad[[interaction_name]] <- ifelse(data_ad$Region == region_level, data_ad$season, 0)
}

## start of model

stan_data_ad <- list(
  N = nrow(data_ad),
  N_ID = length(unique(data_ad$ID)),
  N_regions = length(unique(data_ad$Region_in)), 
  value = data_ad$Value,
  season = data_ad$season,
  interactions = as.matrix(data_ad[, grepl("interaction_", names(data_ad))]),
  ID = data_ad$ID,
  region = data_ad$Region_in)

fit_ad <- stan(file = 'model_stan.stan', 
               data = stan_data_ad, warmup = 2000, iter = 4000, 
               chains = 4, cores = 4,
               control = list(stepsize = 0.01),
               seed = 1234)
print(fit_ad,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3,
      probs = c(.025, .5, .975))

pp_check(stan_data_ad$value,
         extract(fit_ad, pars = "y_rep")$y_rep, #mean of predictions
         fun = "dens_overlay")

obs_min <- min(data_ad$Value)
obs_max <- max(data_ad$Value)
y_rep_samples <- extract(fit_ad, pars = "y_rep")$y_rep
pp_min <- apply(y_rep_samples, 2, min)
pp_max <- apply(y_rep_samples, 2, max)
ppF <- data.frame(
  Stat = c(rep("Min", length(pp_min)), rep("Max", length(pp_max))),
  Value = c(pp_min, pp_max))

ggplot(ppF, aes(x = Stat, y = Value, color = Stat)) +
  geom_jitter(width = 0.1, alpha = 0.5) +
  geom_hline(yintercept = obs_min, linetype = "dashed", color = "blue") +
  geom_hline(yintercept = obs_max, linetype = "dashed", color = "red") +
  labs(title = "Posterior Predictive Check: Min and Max Values",
       y = "Value",
       x = "") +
  theme_bw()

### plot ####
predicted_values_f <- extract(fit_ad)$y_rep
mean_predictions_f <- apply(predicted_values_f, 2, mean) # Mean across rows (samples) for each observation (column)
data_ad$predicted_mean_value <- mean_predictions_f

ad <- ggplot(data_ad, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Axial Diffusivity (aD)", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw()+
  theme(legend.position = "none",
        axis.title.x = element_text(size = 15, margin = margin(t = 15)),
        axis.title.y = element_text(size = 15, margin = margin(r = 15)))

ad_region <- ggplot(data_ad, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Axial Diffusivity (aD) Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  #scale_fill_brewer(palette = "Pastel1", name = "Season", labels = c("Summer", "Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw() +
  theme(legend.position = 'none')

# rd ####
data_rd <- filter(dmi, Metric == "rd") %>%
  filter(Region!= "brainvolume") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_rd$season <- as.numeric(data_rd$season) - 1 
data_rd$ID <- as.integer(data_rd$ID)
data_rd$Region_in <- as.integer(data_rd$Region)
for (region_level in levels(data_rd$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_rd[[interaction_name]] <- ifelse(data_rd$Region == region_level, data_rd$season, 0)
}

## start of model

stan_data_rd <- list(
  N = nrow(data_rd),
  N_ID = length(unique(data_rd$ID)),
  N_regions = length(unique(data_rd$Region_in)), 
  value = data_rd$Value,
  season = data_rd$season,
  interactions = as.matrix(data_rd[, grepl("interaction_", names(data_rd))]),
  ID = data_rd$ID,
  region = data_rd$Region_in)

fit_rd <- stan(file = 'model_stan.stan', 
               data = stan_data_rd, warmup = 2000, iter = 4000, 
               chains = 4, cores = 4,
               control = list(stepsize = 0.01),
               seed = 1234)
print(fit_rd,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3,
      probs = c(.025, .5, .975))

pp_check(stan_data_rd$value,
         extract(fit_rd, pars = "y_rep")$y_rep, #mean of predictions
         fun = "dens_overlay")

### plot ####
predicted_values_f <- extract(fit_rd)$y_rep
mean_predictions_f <- apply(predicted_values_f, 2, mean) # Mean across rows (samples) for each observation (column)
data_rd$predicted_mean_value <- mean_predictions_f

rd <- ggplot(data_rd, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Radial Diffusivity (rD)", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw() +
  theme(legend.position = "none",
        axis.title.x = element_text(size = 15, margin = margin(t = 15)),
        axis.title.y = element_text(size = 15, margin = margin(r = 15)))

rd_region <- ggplot(data_rd, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Radial Diffusivity (rD) Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  #scale_fill_brewer(palette = "Pastel1", name = "Season", labels = c("Summer", "Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw() +
  theme(legend.position = "none")

# md ################
data_md <- filter(dmi, Metric == "md") %>%
  filter(Region!= "brainvolume") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_md$season <- as.numeric(data_md$season) - 1 
data_md$ID <- as.integer(data_md$ID)
data_md$Region_in <- as.integer(data_md$Region)
for (region_level in levels(data_md$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_md[[interaction_name]] <- ifelse(data_md$Region == region_level, data_md$season, 0)
}

## start of model

stan_data_md <- list(
  N = nrow(data_md),
  N_ID = length(unique(data_md$ID)),
  N_regions = length(unique(data_md$Region_in)), 
  value = data_md$Value,
  season = data_md$season,
  interactions = as.matrix(data_md[, grepl("interaction_", names(data_md))]),
  ID = data_md$ID,
  region = data_md$Region_in)

fit_md <- stan(file = 'model_stan.stan', 
               data = stan_data_md, warmup = 2000, iter = 4000, 
               chains = 4, cores = 4,
               control = list(stepsize = 0.01),
               seed = 1234)
print(fit_md,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3,
      probs = c(.025, .5, .975))

pp_check(stan_data_md$value,
         extract(fit_md, pars = "y_rep")$y_rep, #mean of predictions
         fun = "dens_overlay")

### plot ####
predicted_values_f <- extract(fit_md)$y_rep
mean_predictions_f <- apply(predicted_values_f, 2, mean) # Mean across rows (samples) for each observation (column)
data_md$predicted_mean_value <- mean_predictions_f

md <- ggplot(data_md, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Diffusivity (mD)", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw()+
  theme(legend.position = "none",
        axis.title.x = element_text(size = 15, margin = margin(t = 15)),
        axis.title.y = element_text(size = 15, margin = margin(r = 15)))
md_region <- ggplot(data_md, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Mean Diffusivity (mD) Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw() +
  theme(legend.position = "none")

# csf ################
data_csf <- filter(dmi, Metric == "csf") %>%
  filter(Region!= "brainvolume") %>% 
  droplevels() %>% 
  na.omit()

#Modify season
data_csf$season <- as.numeric(data_csf$season) - 1 
data_csf$ID <- as.integer(data_csf$ID)
data_csf$Region_in <- as.integer(data_csf$Region)
for (region_level in levels(data_csf$Region)) {
  interaction_name <- paste0("interaction_", region_level)
  data_csf[[interaction_name]] <- ifelse(data_csf$Region == region_level, data_csf$season, 0)
}

## start of model
stan_data_csf <- list(
  N = nrow(data_csf),
  N_ID = length(unique(data_csf$ID)),
  N_regions = length(unique(data_csf$Region_in)), 
  value = data_csf$Value,
  season = data_csf$season,
  interactions = as.matrix(data_csf[, grepl("interaction_", names(data_csf))]),
  ID = data_csf$ID,
  region = data_csf$Region_in)

fit_csf <- stan(file = 'model_stan.stan', 
               data = stan_data_csf, warmup = 2000, iter = 4000, 
               chains = 4, cores = 4,
               control = list(stepsize = 0.01),
               seed = 1234)
print(fit_csf,
      pars = c('alpha_intercept', 'beta_season', 'beta_interaction', 'phi', 'ID_effects'),
      digits_summary = 3,
      probs = c(.025, .5, .975))

pp_check(stan_data_csf$value,
         extract(fit_csf, pars = "y_rep")$y_rep, #mean of predictions
         fun = "dens_overlay")

### plot ####
predicted_values_f <- extract(fit_csf)$y_rep
mean_predictions_f <- apply(predicted_values_f, 2, mean) # Mean across rows (samples) for each observation (column)
data_csf$predicted_mean_value <- mean_predictions_f

csf <- ggplot(data_csf, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Axial Diffusivity (aD)", y = "Density") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  theme_bw() +
  theme(legend.position = "none",
    axis.title.x = element_text(size = 22, margin = margin(t = 15)), 
    axis.title.y = element_text(size = 22, margin = margin(r = 15)))

csf_region <- ggplot(data_csf, aes(x = predicted_mean_value, fill = as.factor(season))) +
  geom_density(alpha = 0.5) +
  geom_histogram(aes(y=after_stat(density)), alpha = 0.3, bins = 30) +
  labs(x = "Mean Predicted Proportion", y = "Density", title = "Cerebrospinal fluid (CSF) Proportions") +
  scale_fill_manual(values = c("#D16103", "#0A33A9"), labels = c("Summer","Winter")) +
  facet_wrap(~Region, labeller = as_labeller(custom_labels))+
  theme_bw() +
  theme(legend.position = "none")

# Manuscript Main Plot ----
ggpubr::ggarrange(intra, extra, md,  fa, rd, ad, ncol = 3, nrow = 2)
# ggpubr::ggarrange(intra, extra)
# ggpubr::ggarrange(rd, ad)
# ggpubr::ggarrange(fa, md)

# And Region-Specific Plot ----
water_metrics_plot <- (intra_region / extra_region / csf_region)

ggsave("fig_S1_water_volume_proportions.png", water_metrics_plot,
       width = 12, height = 18, dpi = 300)

diffusion_metrics_plot <- (fa_region / md_region / ad_region / rd_region)

ggsave("fig_S2_diffusion_metrics_by_region.png", diffusion_metrics_plot,
       width = 12, height = 18, dpi = 300)


# Correlation between metrics ####
dmi_wide <- dmi %>%
  filter(Metric %in% c("intra", "extra", "fa", "ad", "rd", "md", "csf")) %>%
  select(ID, Region, season, Metric, Value, Volume) %>%
  spread(key = Metric, value = Value) %>%
  na.omit()

ggplot(dmi_wide, aes(x = intra, y = extra, color = Region)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = 'lm', se = FALSE) +
  facet_wrap(~season) +
  theme_bw() +
  labs(x = "Intracellular Water", y = "Extracellular Water", color = "Season")
ggplot(dmi_wide, aes(x = fa, y = ad, color = Region)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = 'lm', se = F) +
  facet_wrap(~season) +
  theme_bw() +
  labs(x = "FA", y = "AD", color = "Season") 
ggplot(dmi_wide, aes(x = fa, y = rd, color = Region)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = 'lm', se = F) +
  facet_wrap(~season) +
  theme_bw() +
  labs(x = "FA", y = "RD", color = "Season") 

## intra ~ extra ####

model_ie <- brm(formula = bf(intra ~ season + extra:season + csf:season + (1|Region) +(1 | ID), family = Beta(link = "logit", link_phi = "log")),
               data = dmi_wide,
               prior = c(prior(normal(0, 1), class = "Intercept"),
                         prior(normal(-1, 1), class = "b", coef = "season2"),
                         prior(normal(-1, 1), class = "b", coef = "season2:extra"),
                         prior(normal(-1, 1), class = "b", coef = "season2:csf"),
                         prior(gamma(4, 0.1), class = "phi"),
                         prior(exponential(1), class = "sd", group = "Region"),
                         prior(exponential(1), class = "sd", group = "ID")),
              chains = 4, cores = 4, iter = 2000, seed = 1234)

p1 = pp_check(model_ie, type = 'stat', stat = 'min') +
  ggtitle('posterior predictive distribution of minimum values') +
  theme_classic()
p2 = pp_check(model_ie, type = 'stat', stat = 'max') +
  ggtitle('posterior predictive distribution of maximum values') +
  theme_classic()
p3 = pp_check(model_ie, type = "stat_2d", stat = c("max", "min")) +
  theme_classic()
p4 = pp_check(model_ie, ndraws = 100)
ggpubr::ggarrange(p1, p2, p3, p4, ncol = 2, nrow = 2)

new_d <- dmi_wide %>%
  distinct(ID,Region, season, extra, csf)
fitted <- fitted(model_ie, newdata = new_d) %>%
  as.data.frame() %>%
  bind_cols(new_d)
fitted_avg <- fitted %>%
  group_by(ID, Region, season, extra) %>%
  summarize(AvgEstimate = mean(Estimate),
            Lower = mean(Q2.5),
            Upper = mean(Q97.5),
            #.groups = 'drop'
            )

colors <- c("#cccccc", "#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4")
combined_colors <- c(brewer.pal(8, "Pastel1"), colors)
region_labels <- c("Amygdala", "AON", "Caudoputamen", "Cerebellum", "Hippocampus", "Midbrain", "Nucleus accumbens", " Neocortex", "Olfactory Bulb", "OT", "Piriform and Enthorinal cortices", "Pons and Medulla", "Thalamus")

seasons_labels <- list("Summer", "Winter")
ggplot(dmi_wide, aes(x = extra, y = intra)) +
  geom_point(aes(fill = Region), alpha = 0.2) +  # Points colored by 'Region'
  geom_ribbon(data = fitted_avg, aes(x = extra, ymin = Lower, ymax = Upper, fill = Region, group = interaction(Region, season)), alpha = 0.8, inherit.aes = FALSE) +
  scale_fill_manual(values = combined_colors, name = "Regions", labels = region_labels) +
  facet_wrap(~season) +
  theme_bw() +
  labs(x = "Extracellular Water", y = "Intracellular Water", fill = "Region")

## fa ~ rd + ad  ####

get_prior(bf(fa ~ season + rd:season + ad:season + (1|Region) +(1 | ID), family = Beta(link = "logit", link_phi = "log")), data = dmi_wide)
model_rdfa <- brm(bf(fa ~ season + rd:season + ad:season + (1|Region) +(1|ID), family = Beta(link = "logit", link_phi = "log")),
                   data = dmi_wide,
                   prior = c(prior(normal(0, 1), class = "Intercept"),
                             prior(normal(-1, 1), class = "b", coef = "season2"),
                             prior(normal(-1, 1), class = "b", coef = "season2:ad"),
                             prior(normal(-1, 1), class = "b", coef = "season2:rd"),
                             prior(gamma(2, 0.1), class = "phi"),
                             prior(exponential(0.2), class = "sd", group = "Region"),
                             prior(exponential(1), class = "sd", group = "ID")),
                   chains = 4, cores = 4, iter = 2000, seed = 1234)

p1 = pp_check(model_rdfa, type = 'stat', stat = 'min') +
  ggtitle('posterior predictive distribution of minimum values') +
  theme_classic()
p2 = pp_check(model_rdfa, type = 'stat', stat = 'max') +
  ggtitle('posterior predictive distribution of maximum values') +
  theme_classic()
p3 = pp_check(model_rdfa, type = "stat_2d", stat = c("max", "min")) +
  theme_classic()
p4 = pp_check(model_rdfa, ndraws = 100)
ggpubr::ggarrange(p1, p2, p3, p4, ncol = 2, nrow = 2)

new_d_rdfa <- dmi_wide %>%
  distinct(ID, Region, season, rd, ad)
fitted_rdfa <- fitted(model_rdfa, newdata = new_d_rdfa) %>%
  as.data.frame() %>%
  bind_cols(new_d_rdfa)

fitted_rdfa <- fitted_rdfa %>%
  group_by(ID, Region, season, rd) %>%
  summarize(AvgEstimate = mean(Estimate),
            Lower = mean(Q2.5),
            Upper = mean(Q97.5),
            .groups = 'drop')

ggplot(dmi_wide, aes(x = rd, y = fa)) +
  geom_point(aes(color = season), alpha = 0.2) + 
  #geom_line(data = fitted_rdfa, aes(x = fa, y = AvgEstimate, color = season, group = season)) +
  geom_ribbon(data = fitted_rdfa, aes(x = rd, ymin = Lower, ymax = Upper, color = season, group = season), alpha = 0.5, inherit.aes = FALSE) +
  labs(x = "RD", y = "FA", color = "Season") +
  facet_wrap(~season) +
  theme_bw()

ggplot(dmi_wide, aes(x = rd, y = fa)) +
  geom_point(aes(fill = Region), alpha = 0.2) + 
  geom_ribbon(data = fitted_rdfa, aes(x = rd, ymin = Lower, ymax = Upper, fill = Region, group = interaction(Region, season)), alpha = 0.8, inherit.aes = FALSE, linewidth = 0) +
  scale_fill_manual(values = combined_colors, name = "Regions", labels = region_labels) +
  facet_wrap(~season) +
  theme_bw() +
  labs(x = "FA", y = "RD", color = "Region", fill = "Region")

# Correlation (Absolute) metrics ####

dmi_wide$vintra_volume <- dmi_wide$intra * dmi_wide$Volume
dmi_wide$vextra_volume <- dmi_wide$extra * dmi_wide$Volume
dmi_wide$vcsf_volume   <- dmi_wide$csf * dmi_wide$Volume
dmi_wide$fa_volume <- dmi_wide$fa * dmi_wide$Volume
dmi_wide$rd_volume <- dmi_wide$rd * dmi_wide$Volume
dmi_wide$md_volume <- dmi_wide$md * dmi_wide$Volume
dmi_wide$ad_volume <- dmi_wide$ad * dmi_wide$Volume

ggplot(dmi_wide, aes(x = vintra_volume, y = vextra_volume)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm") +
  ggtitle("Scatter plot of vintra_volume vs. vextra_volume")
ggplot(dmi_wide, aes(x = vintra_volume, y = vextra_volume, color = Region)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm") +
  ggtitle("Scatter plot of vintra_volume vs. vextra_volume")

model_vintra <- brm(bf(vintra_volume ~ season + vextra_volume:season + vcsf_volume:season + (1|Region) +(1 | ID)),
                          data = dmi_wide,
                          family = Gamma(link = "log"),
                          prior = c(set_prior("normal(0, 1)", class = "b"),
                                    set_prior("cauchy(0, 1)", class = "sd", group = "ID")),
                          control=list(adapt_delta=0.8, max_treedepth = 11),
                          chains = 4, cores = 4, iter = 2000, seed = 123)

nd <-  dmi_wide %>% 
  distinct(ID, season, Region, vextra_volume, vcsf_volume)

fitrw <- fitted(model_vintra, newdata = nd, allow_new_levels = TRUE) %>% 
  data.frame() %>% 
  bind_cols(nd) %>% 
  mutate(season = factor(season),
         ID = factor(ID))

fitted_avgrw <- fitrw %>%
  group_by(ID, season, Region, vextra_volume, vcsf_volume) %>%
  summarize(AvgEstimate = mean(Estimate),
            Lower = mean(Q2.5),
            Upper = mean(Q97.5),
            #.groups = 'drop'
  )

colors <- c("#cccccc", "#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4")
combined_colors <- c(brewer.pal(8, "Pastel1"), colors)
region_labels <- c("Amygdala", "AON", "Caudoputamen", "Cerebellum", "Hippocampus", "Midbrain", "Nucleus accumbens", " Neocortex", "Olfactory Bulb", "OT", "Piriform and Enthorinal cortices", "Pons and Medulla", "Thalamus")

seasons_labels <- list("Summer", "Winter")
ggplot(dmi_wide, aes(x = vextra_volume, y = vintra_volume)) +
  geom_point(aes(fill = Region), alpha = 0.2) +  # Points colored by 'Region'
  geom_ribbon(data = fitted_avgrw, aes(x = vextra_volume, ymin = Lower, ymax = Upper, fill = Region, group = interaction(Region, season)), alpha = 0.8, inherit.aes = FALSE) +
  scale_fill_manual(values = combined_colors, name = "Regions", labels = region_labels) +
  facet_wrap(~season
  ) +
  theme_bw() +
  labs(x = "Extracellular Water", y = "Intracellular Water", fill = "Region")

model_fadrd <- brm(bf(fa_volume ~ season + rd_volume:season + ad_volume:season + (1|Region) +(1 | ID)),
                    data = dmi_wide,
                    family = Gamma(link = "log"),
                    prior = c(prior(normal(0, 1), class = "b"),
                              prior(exponential(0.5), class = "sd", group = "ID"),
                              prior(exponential(0.3), class = "sd", group = "Region")),
                    control=list(adapt_delta=0.8, max_treedepth = 11),
                    chains = 4, cores = 4, iter = 2000, seed = 123)

# Is there correlation between change in volume - change in metrics ####

summer_data <- dmi_wide %>% filter(season == 1)
winter_data <- dmi_wide %>% filter(season == 2)

change_data <- summer_data %>%
  inner_join(winter_data, by = c("ID", "Region"), suffix = c("_summer", "_winter")) %>%
  mutate(
    change_volume = Volume_winter - Volume_summer,
    change_intra = intra_winter - intra_summer,
    change_extra = extra_winter - extra_summer,
    change_csf = csf_winter - csf_summer,
    change_fa = fa_winter - fa_summer,
    change_md = md_winter - md_summer,
    change_ad = ad_winter - ad_summer,
    change_rd = rd_winter - rd_summer
  ) %>%
  select(ID, Region, change_volume, change_intra, change_extra, change_csf, change_fa, change_md, change_ad, change_rd)

#Check dataset
head(change_data)

get_prior(change_volume ~ change_intra + change_extra + change_csf + (1 | Region) + (1 | ID),
          data = change_data, family = gaussian())
model_change_correlation <- brm(change_volume ~ change_intra + change_extra + change_csf + (1 | Region) + (1 | ID),
                                data = change_data, family = gaussian(), 
                                prior = c(prior(normal(0, 1), class = "Intercept"),
                                          prior(normal(0, 1), class = "b", coef = "change_intra"),
                                          prior(normal(0, 1), class = "b", coef = "change_extra"),
                                          prior(normal(0, 1), class = "b", coef = "change_csf"),
                                          prior(exponential(1), class = "sd", group = "Region"),
                                          prior(exponential(1), class = "sd", group = "ID")),
                                control=list(adapt_delta=0.8, max_treedepth = 11),
                                chains = 4, cores = 4, iter = 2000, seed = 123)

plot(conditional_effects(model_change_correlation), points = TRUE)

