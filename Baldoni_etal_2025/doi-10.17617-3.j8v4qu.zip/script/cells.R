# Use renv to restore the packages
renv::restore()

# Load Libraries ####
library(here)
library(tidyverse)
library(brms)
library(gridExtra)
library(patchwork)

cells <- read.csv2(here("data", "brain_cell_counts.csv"), sep = ",", dec = ".")

str(cells$Group)
cells <- cells %>% 
  mutate(Group = as.factor(Group))
cells$Season <- ifelse(cells$Group == "Summer Adult", "spring", 
                      ifelse(cells$Group == "Summer Juvenile", "summer", "winter"))
cells <- cells %>% 
  mutate(Season = as.factor(Season))
cells <- cells %>% 
  mutate(id = as.factor(id),
         animal = as.factor(animal),
         Season = as.factor(Season),
         phase = as.factor(phase),
         sex = as.factor(sex)) %>% 
  filter(Season != "spring")%>% 
  droplevels() 
cells$Season <- relevel(cells$Season, ref = "summer")

ggplot(data = cells) +
  geom_boxplot(aes(x = Season, y = total_all))
ggplot(data = cells) +
  geom_boxplot(aes(x = Season, y = brain_vol)) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  theme_bw() +

str(cells)

## All cells ####
cells_long <- reshape2::melt(cells, id.vars = c("id", "animal", "Season", "phase", "sex"),
                            measure.vars = c("total_all", "ob_all", "neo_all", "nac_all", "cau_all", "amy_all", "hip_all"),
                            variable.name = "region", value.name = "count")
str(cells_long)

get_prior(bf(count ~ Season*region + (1|animal)), data = cells_long, family = negbinomial())
fit_all <- brm(bf(count ~ Season:region + (1|animal)), data = cells_long, family = negbinomial(),
               prior = c(prior(normal(0,2), class = "b"),
                         prior(exponential(0.8), class = "sd", group = "animal")),
               chains = 4, iter = 5000, warmup = 1000, cores = 4, seed = "1234",
               control=list(adapt_delta=0.999, max_treedepth = 13))
conditional_effects(fit_all, effects = "Season:region")

hypotheses <- c(
  "Seasonwinter:regiontotal_all - Seasonsummer:regiontotal_all = 0",
  "Seasonwinter:regionob_all - Seasonsummer:regionob_all = 0",
  "Seasonwinter:regionneo_all - Seasonsummer:regionneo_all = 0",
  "Seasonwinter:regionnac_all - Seasonsummer:regionnac_all = 0",
  "Seasonwinter:regioncau_all - Seasonsummer:regioncau_all = 0",
  "Seasonwinter:regionamy_all - Seasonsummer:regionamy_all = 0",
  "Seasonwinter:regionhip_all - Seasonsummer:regionhip_all = 0")

results <- hypothesis(fit_all, hypotheses)
print(results)

ggplot(data= cells_long) +
  geom_boxplot(aes(x = Season, y = count, colour = region)) +
  facet_wrap(~region)

predicted_counts <- predict(fit_all, type = "response", re.form = NA)
predicted_count <- data.frame(Season = cells_long$Season, region = cells_long$region, Predicted_Count = predicted_counts)
predicted_count <- predicted_count %>%
  group_by(Season, region) %>%
  summarise(Mean_Predicted_Count = mean(Predicted_Count.Estimate),
            Lower_CI = mean(Predicted_Count.Q2.5),
            Upper_CI = mean(Predicted_Count.Q97.5),
            .groups = 'drop')
predicted_count$Season <- factor(predicted_count$Season, levels = levels(cells_long$Season))
predicted_count$region <- factor(predicted_count$region, levels = levels(cells_long$region))
predicted_count <- as.data.frame(predicted_count)
str(predicted_count)

custom_labels <- c(
  total_all = "All Brain",
  ob_all = "Olfactory Bulb",
  neo_all = "Neocortex",
  nac_all = "Nucleus Accumbens",
  cau_all = "Caudoputamen",
  amy_all = "Amygdala",
  hip_all = "Hippocampus"
)
ggplot() +
  geom_boxplot(data = cells_long %>%filter(region != "total_all"), aes(x = Season, y = count, fill = region), alpha = 0.4) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels))) +
  geom_point(data = predicted_count%>%filter(region != "total_all"), aes(x = Season, y = Mean_Predicted_Count, color = region), size = 3) +
  geom_errorbar(data = predicted_count%>%filter(region != "total_all"), aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), width = 0.5) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  theme_bw() +
  theme(legend.position="none") +
  labs(x = "Season", y = "Count")

regions <- unique(cells_long$region)
color_palette <- c(total_all = "#1f77b4", ob_all = "#ff7f0e", neo_all = "#2ca02c",
                   nac_all = "#d62728", cau_all = "#9467bd", amy_all = "#8c564b",  hip_all = "#e377c2")

custom_labels <- c(total_all = "All Brain",
                   ob_all = "Olfactory Bulb",
                   neo_all = "Neocortex",
                   nac_all = "Nucleus Accumbens",
                   cau_all = "Caudoputamen",
                   amy_all = "Amygdala",
                   hip_all = "Hippocampus")

plot_list <- list()
regions <- unique(cells_long$region)

for (current_region in regions) {
  filtered_cells <- cells_long %>% filter(region == current_region)
  filtered_predictions <- predicted_count %>% filter(region == current_region)
  
  #use a unique color for each region from the palette
  region_color <- color_palette[current_region]
  
  p <- ggplot() +
    geom_boxplot(data = filtered_cells, aes(x = Season, y = count),fill = region_color, alpha = 0.4) +
    geom_point(data = filtered_predictions, aes(x = Season, y = Mean_Predicted_Count), size = 3, color = region_color) +
    geom_errorbar(data = filtered_predictions, aes(x = Season, ymin = Lower_CI, ymax = Upper_CI), width = 0.5, color = region_color) +
    scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
    theme_bw() +
    theme(legend.position="none") +
    labs(title = custom_labels[current_region], x = "Season", y = "All Cells Count")
  
  plot_list[[current_region]] <- p
}


## Neurons ####

cells_neu <- reshape2::melt(cells, id.vars = c("id", "animal", "Season", "phase", "sex"),
                             measure.vars = c("total_neu", "ob_neu", "neo_neu", "nac_neu", "cau_neu", "amy_neu", "hip_neu"),
                             variable.name = "region", value.name = "count")
str(cells_neu)

get_prior(bf(count ~ Season:region + (1|animal)), data = cells_neu, family = negbinomial())
fit_neu <- brm(bf(count ~ Season:region + (1|animal)), data = cells_neu, family = negbinomial(),
               prior = c(prior(normal(0,1), class = "b"),
                         prior(exponential(0.7), class = "sd", group = "animal")),
               chains = 4, iter = 5000, warmup = 1000, cores = 4, seed = "1234",
               control=list(adapt_delta=0.999, max_treedepth = 13))

conditional_effects(fit_neu, effects = "Season:region")


hypotheses_neu <- c("Seasonwinter:regiontotal_neu - Seasonsummer:regiontotal_neu = 0",
                    "Seasonwinter:regionob_neu - Seasonsummer:regionob_neu = 0",
                    "Seasonwinter:regionneo_neu - Seasonsummer:regionneo_neu = 0",
                    "Seasonwinter:regionnac_neu - Seasonsummer:regionnac_neu = 0",
                    "Seasonwinter:regioncau_neu - Seasonsummer:regioncau_neu = 0",
                    "Seasonwinter:regionamy_neu - Seasonsummer:regionamy_neu = 0",
                    "Seasonwinter:regionhip_neu - Seasonsummer:regionhip_neu = 0")

hypothesis(fit_neu, hypotheses_neu)

predicted_neurons <- predict(fit_neu, type = "response", re.form = NA)
predicted_neu <- data.frame(Season = cells_neu$Season, region = cells_neu$region, Predicted_Count = predicted_neurons)
predicted_neu <- predicted_neu %>%
  group_by(Season, region) %>%
  summarise(Mean_Predicted_Count = mean(Predicted_Count.Estimate),
            Lower_CI = mean(Predicted_Count.Q2.5),
            Upper_CI = mean(Predicted_Count.Q97.5),
            .groups = 'drop')
predicted_neu$Season <- factor(predicted_neu$Season, levels = levels(cells_neu$Season))
predicted_neu$region <- factor(predicted_neu$region, levels = levels(cells_neu$region))
predicted_neu <- as.data.frame(predicted_neu)
str(predicted_neu)

custom_labels_neu <- c(  total_neu = "All Brain",
                         ob_neu = "Olfactory Bulb",
                         neo_neu = "Neocortex",
                         nac_neu = "Nucleus Accumbens",
                         cau_neu = "Caudoputamen",
                         amy_neu = "Amygdala",
                         hip_neu = "Hippocampus")
ggplot() +
  geom_boxplot(data = cells_neu, aes(x = Season, y = count, fill = region), alpha = 0.4) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels_neu))) +
  geom_point(data = predicted_neu, aes(x = Season, y = Mean_Predicted_Count, color = region), size = 3) +
  geom_errorbar(data = predicted_neu, aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), width = 0.5) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  theme_bw() +
  theme(legend.position="none") +
  labs(x = "Season", y = "Neuron Count")

regions <- unique(cells_long$region)
color_palette_neu <- c(total_neu = "#1f77b4", ob_neu = "#ff7f0e", neo_neu = "#2ca02c",
                   nac_neu = "#d62728", cau_neu = "#9467bd", amy_neu = "#8c564b",  hip_neu = "#e377c2")

custom_labels_neu <- c(total_neu = "All Brain",
                   ob_neu = "Olfactory Bulb",
                   neo_neu = "Neocortex",
                   nac_neu = "Nucleus Accumbens",
                   cau_neu = "Caudoputamen",
                   amy_neu = "Amygdala",
                   hip_neu = "Hippocampus")

plot_list <- list()
regions <- unique(cells_long$region)

for (current_region in regions) {
  filtered_neu <- cells_neu %>% filter(region == current_region)
  filtered_predictions_neu <- predicted_neu %>% filter(region == current_region)

  region_color <- color_palette[current_region]
  
  p <- ggplot() +
    geom_boxplot(data = filtered_neu, aes(x = Season, y = count),fill = region_color, alpha = 0.4) +
    geom_point(data = filtered_predictions_neu, aes(x = Season, y = Mean_Predicted_Count), size = 3, color = region_color) +
    geom_errorbar(data = filtered_predictions_neu, aes(x = Season, ymin = Lower_CI, ymax = Upper_CI), width = 0.5, color = region_color) +
    scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
    theme_bw() +
    theme(legend.position="none") +
    labs(title = custom_labels[current_region], x = "Season", y = "Neuron Count")
  
  plot_list[[current_region]] <- p
}

# Total cell plot (panel a)
p_total_cells <- cells_long %>% 
  ggplot(aes(x = Season, y = count, color = region)) +
  geom_jitter(width = 0.2, size = 2, alpha = 0.8) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels))) +
  geom_point(data = predicted_count,
             aes(x = Season, y = Mean_Predicted_Count, color = region),
             size = 3, inherit.aes = FALSE) +
  geom_errorbar(data = predicted_count,
                aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), alpha = 0.5,
                width = 0.5, inherit.aes = FALSE) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  labs(title = "Total Cells", x = "Season", y = "Total Cell Count") +
  theme_bw(base_size = 12) +
  theme(legend.position = "none",
        strip.text = element_text(face = "bold"))

# Neuron plot (panel b)
p_neuron <- cells_neu %>%
  ggplot(aes(x = Season, y = count, color = region)) +
  geom_jitter(width = 0.2, size = 2, alpha = 0.8) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels_neu))) +
  geom_point(data = predicted_neu,
             aes(x = Season, y = Mean_Predicted_Count, color = region),
             size = 3, inherit.aes = FALSE) +
  geom_errorbar(data = predicted_neu,
                aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), alpha = 0.5,
                width = 0.5, inherit.aes = FALSE) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  labs(title = "Neurons", y = "Neuron Count", x = "") +
  theme_bw(base_size = 12) +
  theme(legend.position = "none",
        strip.text = element_text(face = "bold"))


p_total_cells/ p_neuron


## Glia ####

cells_gl <- reshape2::melt(cells, id.vars = c("id", "animal", "Season", "phase", "sex"),
                            measure.vars = c("total_gl", "neo_gl", "nac_gl", "cau_gl", "amy_gl", "hip_gl"),
                            variable.name = "region", value.name = "count")
str(cells_gl)

get_prior(bf(count ~ Season:region + (1|animal)), data = cells_gl, family = negbinomial())
fit_gl <- brm(bf(count ~ Season:region + (1|animal)), data = cells_gl, family = negbinomial(),
               prior = c(prior(normal(0,1), class = "b"),
                         prior(exponential(0.7), class = "sd", group = "animal")),
               chains = 4, iter = 5000, warmup = 1000, cores = 4, seed = "1234",
               control=list(adapt_delta=0.999, max_treedepth = 13))

conditional_effects(fit_gl, effects = "Season:region")


hypotheses_gl <- c("Seasonwinter:regiontotal_gl - Seasonsummer:regiontotal_gl = 0",
                    "Seasonwinter:regionneo_gl - Seasonsummer:regionneo_gl = 0",
                    "Seasonwinter:regionnac_gl - Seasonsummer:regionnac_gl = 0",
                    "Seasonwinter:regioncau_gl - Seasonsummer:regioncau_gl = 0",
                    "Seasonwinter:regionamy_gl - Seasonsummer:regionamy_gl = 0",
                    "Seasonwinter:regionhip_gl - Seasonsummer:regionhip_gl = 0")

hypothesis(fit_gl, hypotheses_gl)

predicted_glia<- predict(fit_gl, type = "response", re.form = NA)
predicted_gl <- data.frame(Season = cells_gl$Season, region = cells_gl$region, Predicted_Count = predicted_glia)
predicted_gl <- predicted_gl %>%
  group_by(Season, region) %>%
  summarise(Mean_Predicted_Count = mean(Predicted_Count.Estimate),
            Lower_CI = mean(Predicted_Count.Q2.5),
            Upper_CI = mean(Predicted_Count.Q97.5),
            .groups = 'drop')
predicted_gl$Season <- factor(predicted_gl$Season, levels = levels(cells_gl$Season))
predicted_gl$region <- factor(predicted_gl$region, levels = levels(cells_gl$region))
predicted_gl <- as.data.frame(predicted_gl)
str(predicted_gl)

custom_labels_gl <- c(total_gl = "All Brain", 
                      neo_gl = "Neocortex", nac_gl = "Nucleus Accumbens",
                      cau_gl = "Caudoputamen", amy_gl = "Amygdala", hip_gl = "Hippocampus")
ggplot() +
  geom_boxplot(data = cells_gl, aes(x = Season, y = count, fill = region), alpha = 0.4) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels_gl))) +
  geom_point(data = predicted_gl, aes(x = Season, y = Mean_Predicted_Count, color = region), size = 3) +
  geom_errorbar(data = predicted_gl, aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), width = 0.5) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  theme_bw() +
  theme(legend.position="none") +
  labs(x = "Season", y = "Glia Count")

regions <- unique(cells_long$region)
color_palette_gl <- c(total_gl = "#1f77b4", neo_gl = "#2ca02c",
                       nac_gl = "#d62728", cau_gl = "#9467bd", amy_gl = "#8c564b",  hip_gl = "#e377c2")

custom_labels_gl <- c(total_gl = "All Brain",
                       neo_gl = "Neocortex",
                       nac_gl = "Nucleus Accumbens",
                       cau_gl = "Caudoputamen",
                       amy_gl = "Amygdala",
                       hip_gl = "Hippocampus")

# Glia plot (panel b)
p_glia <- cells_gl %>%
  ggplot(aes(x = Season, y = count, color = region)) +
  geom_jitter(width = 0.2, size = 2, alpha = 0.8) +
  facet_wrap(~region, scales = "free", labeller = labeller(region = as_labeller(custom_labels_gl))) +
  geom_point(data = predicted_gl,
             aes(x = Season, y = Mean_Predicted_Count, color = region),
             size = 3, inherit.aes = FALSE) +
  geom_errorbar(data = predicted_gl,
                aes(x = Season, ymin = Lower_CI, ymax = Upper_CI, color = region), alpha = 0.5,
                width = 0.5, inherit.aes = FALSE) +
  scale_x_discrete(labels = c("summer" = "Summer", "winter" = "Winter")) +
  labs(y = "Glia Count", x = "") +
  theme_bw(base_size = 12) +
  theme(legend.position = "none",
        strip.text = element_text(face = "bold"))
