data {
  int<lower=1> N;                      // sample size
  int<lower=1> K;                      // Total number of predictors, including interactions
  vector<lower=0, upper=1>[N] Value;       // Response variable
  matrix[N, K] X;                      // Predictor matrix, including main effects and interactions
}

parameters {
  vector[K] b;                     // Regression coefficients for predictors and interactions
  real<lower=0> phi;                   // Precision parameter of the beta distribution
}

transformed parameters {
  vector[N] mu;                        // Expected value of the response variable
  mu = inv_logit(X * b);
  //for (i in 1:N) {
    
    //mu[i] = inv_logit(dot_product(X[i], b));  // Correctly compute mu[i] here
    //mu[i] = fmax(fmin(mu[i], 1.0 - 1e-10), 1e-10);  // Then ensure it stays within bounds
 // }
}

model {
  // Priors
  b ~ normal(0, 1);  // Assuming a normal(0,1) prior for each coefficient in b
  phi ~ cauchy(0,5);
  
  // Likelihood
  for (i in 1:N) {
    Value[i] ~ beta(mu[i] * phi, (1 - mu[i]) * phi);
  }
}

generated quantities {
  vector[N] y_rep;

  for (i in 1:N) {
    y_rep[i] = beta_rng(mu[i] * phi, (1 - mu[i]) * phi);  // Simulate replicated data
  }
}
